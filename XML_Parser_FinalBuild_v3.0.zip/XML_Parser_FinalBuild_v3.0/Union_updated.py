import xml.dom.minidom as minidom
import re
import pandas as pd
from collections import OrderedDict
import sys
import json
import subprocess, json
import itertools
from functools import reduce
import numpy as np
from xlwt import Workbook
# import openpyxl

###input_file = "C:/Users/kanish/Desktop/UNDIAL FI/m_STG_TO_HOPM_S_TXN_CPPH_HIST_LOAD_MONTHLY_REWARD.xml"
# outfile = "C:/Users/kanish/Desktop/UNDIAL FI/m_acc0051_P100_staging_to_AP.csv"

Flag='Y'
FL3 = 'Y'
def union_transformation(a):
    input_file =a

    DOMTree = minidom.parse(input_file)
    FL1='Y'
    FL2='Y'
    FL3 = 'Y'
    final_list = []
    IM_list1=[]
    IM_list2=[]
    transformation_dict = {}

    main_tag_list = DOMTree.getElementsByTagName("TRANSFORMATION")
    for Type in main_tag_list:
        transformation_TYPE = Type.getAttribute('TYPE')
        transformation_TEMPLATE = Type.getAttribute('TEMPLATENAME')
        instance_TYPE = Type.getAttribute('NAME')

        # print(transformation_TYPE)
        if transformation_TEMPLATE == "Union Transformation":
            transformation_list = Type.getElementsByTagName("GROUP")
            filter_list = Type.getElementsByTagName("TRANSFORMFIELD")


            for transformation in transformation_list:
                row = []
                row.append(instance_TYPE)
                ###field_transformation_name = transformation.getAttribute('NAME')
                ###row.append(str(field_transformation_name))
                row.append(transformation_TYPE)
                row.append(transformation_TEMPLATE)
                field_transformation_name = transformation.getAttribute('NAME')
                row.append(str(field_transformation_name))
                field_transformation_name = transformation.getAttribute('DESCRIPTION')
                row.append(str(field_transformation_name))
                IM_list1.append(row)
            for Filter in filter_list:
                row1=[]
                field_transformation_name = Filter.getAttribute('NAME')
                row1.append(str(field_transformation_name))
                field_transformation_name = Filter.getAttribute('GROUP')
                row1.append(str(field_transformation_name))
                IM_list2.append(row1)
    # print(IM_list1)
    DF1 = pd.DataFrame(IM_list1)
    if DF1.empty:
        FL1='N'
    else:
        DF1.columns = ['Instance Name', 'Transformation type','TRANSFORMATION TEMPLATE','GROUP','DESCRIPTION']
    DF2 = pd.DataFrame(IM_list2)
    if DF2.empty:
        FL2='N'
    else:
        DF2.columns = ['NAME','GROUP']
    if FL1=='Y' and FL2=='Y':
        merged_df = pd.merge(left=DF1, right=DF2, how='inner', on='GROUP')
        final_list = merged_df.values.tolist()
    # print (final_list)
    df = pd.DataFrame(final_list)
    # print(df)
    if df.empty:
        FL3 = 'N'

    if FL3 != 'N':
        # print(FL3)
        df.columns = ['Instance Name', 'TRANSFORMATION_TYPE', 'TRANSFORMATION TEMPLATE', 'GROUP NAME',
                      'GROUP DESCRIPTION', 'COLUMN NAME']
        ###df.columns = ['Instance Name','Transformation type', 'GROUP','EXPRESSION','Column_Name']
        ###df.columns

    return df


# final_list1=transformation_extract("C:/Users/kanish/Desktop/UNDIAL FI/m_acc0051_P100_staging_to_AP.XML")
# print('Flag='+Flag)




