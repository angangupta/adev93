#!/usr/bin/env python
# coding: utf-8

# In[18]:

import xml.etree.ElementTree as ET
import csv
import os
import pandas as pd

def aggregator_transform(filename):
    
    
    tree = ET.parse(filename)
    root=tree.getroot()
    # print(root.attrib.get("NAME"))
    filter_df=pd.DataFrame([])
    c=tree.iter('TRANSFORMATION')
    for node in c:
        nameofexp = node.attrib.get('NAME')
        typ = node.attrib.get('TYPE')
        if (typ=="Aggregator"):
            aggregator_name=nameofexp
            aggregator_typ=typ
            transfield_list=node.findall("TRANSFORMFIELD")
            for xx in transfield_list:
                Trans_fieldname=xx.attrib.get('NAME')
                Trans_fieldnexpr_name=xx.attrib.get('EXPRESSION')
                Trans_fieldexprtyp=xx.attrib.get('EXPRESSIONTYPE')
                Trans_fieldporttype=xx.attrib.get('PORTTYPE')
                filter_df=filter_df.append(pd.DataFrame({'Script Name':filename.rsplit('/')[-1].replace('.XML',''), 'Input Transformation':nameofexp, 'Transformation Type': typ,
                                        'Field Name': Trans_fieldname,
                                        'Aggregator Expression': Trans_fieldnexpr_name,
                                        'Aggregator Type': Trans_fieldexprtyp,
                                        'Aggregator Port Type': Trans_fieldporttype,
                                                        }, index=[0]))
    
    
    return filter_df;



# In[ ]:




