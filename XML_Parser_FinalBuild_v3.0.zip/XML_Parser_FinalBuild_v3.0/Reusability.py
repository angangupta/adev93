#!/usr/bin/env python
# coding: utf-8

# In[18]:

import xml.etree.ElementTree as ET
import csv
import os
import pandas as pd


def transformation_reusability(filename):
    tree = ET.parse(filename)
    root = tree.getroot()
    # print(root.attrib.get("NAME"))
    filter_df = pd.DataFrame([])
    c = tree.iter('TRANSFORMATION')
    for node in c:
        nameofexp = node.attrib.get('NAME')
        typ = node.attrib.get('REUSABLE')
        if (typ == "YES"):
            filter_df = filter_df.append(pd.DataFrame(
                {'Script Name': filename.rsplit('/')[-1].replace('.XML', ''), 'Input Transformation': nameofexp,
                 'Resusable': typ,
                 }, index=[0]))

    return filter_df;

# In[ ]:




