#!/usr/bin/env python
# coding: utf-8

# In[7]:

import xml.etree.ElementTree as ET
import csv
import os
import pandas as pd

def sorter_transform(filename):
    
    
    tree = ET.parse(filename)
    root=tree.getroot()
    # print(root.attrib.get("NAME"))
    filter_df=pd.DataFrame([])
    c=tree.iter('TRANSFORMATION')
    for node in c:
        nameofexp = node.attrib.get('NAME')
        typ = node.attrib.get('TYPE')
        if (typ=="Sorter"):
            aggregator_name=nameofexp
            aggregator_typ=typ
            transfield_list=node.findall("TRANSFORMFIELD")
            for xx in transfield_list:
                Trans_fieldname=xx.attrib.get('NAME')
                Trans_sortkey=xx.attrib.get('ISSORTKEY')
                Trans_sorttype=xx.attrib.get('SORTDIRECTION')
                filter_df=filter_df.append(pd.DataFrame({'Script Name':filename.rsplit('/')[-1].replace('.XML',''), 'Input Transformation':nameofexp, 'Transformation Type': typ,
                                        'Field Name': Trans_fieldname,
                                        'Is_SortKey?': Trans_sortkey,
                                        'Sort Order': Trans_sorttype,
                                                        }, index=[0]))
    
    #filter_df.to_csv("/Users/poojjoshi/Documents/Firm Initiative/Undial/outputFiles/sortor.csv",header=True,index = False)
    return filter_df



# In[ ]:




