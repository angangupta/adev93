import xml.dom.minidom as minidom
import os
import re
import pandas as pd
from collections import OrderedDict
import sys
import json
import subprocess,json
import itertools
from functools import reduce
import numpy as np
from xlwt import Workbook
import datetime
from Expression_transformation_snippet import transformation_extract
from source_qualifier import source_qualifier_extract
from Pre_Post_SQLExtraction_Function import prepostSQLtrans
from Source_Target_DB_Extract_Function import Source_Target_DB_Extract_trans
#from Joiner_extract_Function import Joiner_transform
from Joiner_Lookup_extract_v2 import joiner_lookup_transform
from Filter_Extract import filter_transform
from router_snippet_updated import router_transformation_extract
from Sorter_Transform import sorter_transform
from Aggregator_Extract import aggregator_transform
from Reusability import transformation_reusability
from Union_updated import union_transformation

#Globall Variable Declaration
final_dataframe_list=[]
log_dataframe_list=[]
file_index=0
final_dataframe=pd.DataFrame()
activity_start_time=str(datetime.datetime.now())



#Pre processing tasks
# FORMAT = '%Y%m%d%H%M%S'
# path = 'XML_PARSE_LOG.txt'
# readable = '%s_%s' % (datetime.datetime.now().strftime(FORMAT), path)
# f = open(readable, 'a+')
print("XML Parse Activity Started")
print("Activity Start Time: " + str(datetime.datetime.now()) + "\n")

#Processing XML File begins
for filename in os.listdir("input"):
    log_row=[]
    log_row.append(str(datetime.datetime.now()) + "\n")
    input_file=filename
    file_index=file_index+1
    DOMTree = minidom.parse(input_file)
    # transformations = minidom.parse(input_file)
    df_expression=transformation_extract(input_file)
    df_sql_override=source_qualifier_extract(input_file)
    df_src_target_db_extract=Source_Target_DB_Extract_trans(input_file)
    df_jnr_lkp_transform = joiner_lookup_transform(input_file)
    df_fiter_extract = filter_transform(input_file)
    df_pre_post_sql=prepostSQLtrans(input_file)
    df_router=router_transformation_extract(input_file)
    df_sorter=sorter_transform(input_file)
    df_aggregator=aggregator_transform(input_file)
    df_reusability=transformation_reusability(input_file)
    df_union=union_transformation(input_file)

    transformation_dict = {}
    connector_list = DOMTree.getElementsByTagName("CONNECTOR")
    transformation_tag_list = DOMTree.getElementsByTagName("TRANSFORMATION")
    reusable_trans_dict={}

    for transformation in transformation_tag_list:
        reusable_trans_dict[str(transformation.getAttribute("NAME"))]=str(transformation.getAttribute("REUSABLE"))

    print(reusable_trans_dict)
    target_field_instance_list=[]
    target_to_source_linked_dict={}

    mapping_list=DOMTree.getElementsByTagName("MAPPING")
    for mapping in mapping_list:
        mapping_name=mapping.getAttribute("NAME")

    for connector in connector_list:
        row=[]
        row.append(connector.getAttribute("TOINSTANCETYPE"))
        row.append(connector.getAttribute("TOINSTANCE"))
        row.append(connector.getAttribute("TOFIELD"))
        if (row not in target_field_instance_list):
            target_field_instance_list.append(row)

    def instance_wise_target_fields_list(instance_name,list):
        for connector in connector_list:
            if(str(connector.getAttribute("TOINSTANCE"))==instance_name and [str(connector.getAttribute("TOINSTANCETYPE")),str(connector.getAttribute("TOINSTANCE")),str(connector.getAttribute("TOFIELD"))] not in list):
                list.append([str(connector.getAttribute("TOINSTANCETYPE")),str(connector.getAttribute("TOINSTANCE")),str(connector.getAttribute("TOFIELD"))])
        return list


    def create_linked_list(instance_name,list):
        #print("create_linked_list")
        for connector in connector_list:
            if(instance_name in str(connector.getAttribute("TOINSTANCE")) and [str(connector.getAttribute("FROMINSTANCE")),str(connector.getAttribute("FROMINSTANCETYPE")),str(connector.getAttribute("TOINSTANCE")),str(connector.getAttribute("TOINSTANCETYPE"))] not in list):
                list.append([str(connector.getAttribute("FROMINSTANCE")),str(connector.getAttribute("FROMINSTANCETYPE")),str(connector.getAttribute("TOINSTANCE")),str(connector.getAttribute("TOINSTANCETYPE"))])
                create_linked_list(str(connector.getAttribute("FROMINSTANCE")), list)
        return list


    target_wise_linked_dict={}
    progress=0
    for connector in connector_list:
        progress=progress+1
        complete_progress=progress*100/len(connector_list)
        print("Connector List : " + str(complete_progress) + "% Complete")
        if(connector.getAttribute("TOINSTANCETYPE")=="Target Definition"):
            list=[]
            list.append(connector.getAttribute("TOINSTANCE"))
            transformation_list=create_linked_list(str(connector.getAttribute("TOINSTANCE")),list)
            if(str(connector.getAttribute("TOINSTANCE")) not in target_wise_linked_dict.keys()):
                target_wise_linked_dict[str(connector.getAttribute("TOINSTANCE"))]=transformation_list
            #print(transformation_list)

    #(target_wise_linked_dict)

    def target_source_mapping(target_row):
        #print("target_source_mapping")
        for connector in connector_list:
            source_row=['','','']
            if(connector.getAttribute("TOINSTANCETYPE")==target_row[0] and connector.getAttribute("TOINSTANCE")==target_row[1] and connector.getAttribute("TOFIELD")==target_row[2]):
                source_row=[str(connector.getAttribute("FROMINSTANCETYPE")),str(connector.getAttribute("FROMINSTANCE")),str(connector.getAttribute("FROMFIELD"))]
                return (source_row)
    #
    # #
    def sorted_list(original_list):
        #print("sorted_list")
        sorted_list=[]
        for key in original_list:
                if(key[3]=="Target Definition" and key[0] not in sorted_list ):
                    sorted_list.append(key[2])
                    sorted_list.append(key[0])
                    # print(key[1])
                else:
                    for key2 in original_list:
                        if key2[0] ==key[0] and key2[2] !=key[2] and key2[0] not in sorted_list:
                            sorted_list.append(key2[0])
                            # print(key2[1])
                        elif key2[2] ==key[2] and key2[0] !=key[0] and key2[0] not in sorted_list:
                            sorted_list.append(key2[0])
                            # print(key2[1])
                        #elif(key2[2] ==key[0] and  key2[0] not in sorted_list):
                            #sorted_list.append(key2[0])
                    if key[0] not in sorted_list:
                        sorted_list.append(key[0])
                        # print(key[1])
        return sorted_list

    #Main Code Starts

    target_index=0
    key_index=0
    base_list=[]
    # print("Creating Base Dataframe..")
    for target in target_wise_linked_dict.keys():
        dataframe_list = []
        dataframe_list2 = []
        target_index=target_index+1

        for key in reversed(sorted_list(target_wise_linked_dict[target])):

            #print(key)
            key_field_list=instance_wise_target_fields_list(key,[])
            for key_field in key_field_list:
                key_index=key_index+1
                base_list.append([file_index,target_index,key_index,target_source_mapping(key_field)[0],target_source_mapping(key_field)[1],target_source_mapping(key_field)[2],key_field[0],key_field[1],key_field[2]])

    base_df = pd.DataFrame(columns=['File Index','Target Index','Key Index','Source Instance Type', 'Source Instance Name', 'Source Field Name','Target Instance Type', 'Target Instance Name', 'Target Field Name'],
                                   data=base_list)
    # print("Merging Expression..")
    merged_df = pd.merge(base_df, df_expression, how="outer", left_on=['Source Instance Name', 'Source Field Name'],
                         right_on=['Instance Name', 'Field Name'])
    # print("Merging SQL Override..")
    if len(df_sql_override)!=0:
        merged_df = pd.merge(merged_df, df_sql_override, how="outer", left_on=['Source Instance Name'],
                             right_on=['Instance Name'])
    # print("Merging Pre Post SQL Expression..")
    if len(df_pre_post_sql)!=0:
        merged_df = pd.merge(merged_df, df_pre_post_sql, how="outer", left_on=['Source Instance Name'],
                             right_on=['Input Transformation'])
    # print("Merging SRC TGT DB Extract..")
    if len(df_src_target_db_extract)!=0:
        merged_df = pd.merge(merged_df, df_src_target_db_extract, how="outer", left_on=['Source Instance Name'],
                             right_on=['Input Transformation'])
    # print("Merging Joiner LKP Transformation..")
    if len(df_jnr_lkp_transform)!=0:
        merged_df = pd.merge(merged_df, df_jnr_lkp_transform, how="outer", left_on=['Source Instance Name'],
                             right_on=['Input Transformation'])
    # print("Merging Filter Extract..")
    if len(df_fiter_extract)!=0:
        merged_df = pd.merge(merged_df, df_fiter_extract, how="outer", left_on=['Source Instance Name', 'Source Field Name'],
                             right_on=['Input Transformation','Field Name'])
    # print("Merging Router..")
    if(len(df_router))!=0:
        merged_df = pd.merge(merged_df, df_router, how="outer", left_on=['Source Instance Name','Source Field Name'],
                             right_on=['Instance Name','FIELD NAME'])
    print("Merging Sorter..")
    if len(df_sorter) != 0:
        merged_df = pd.merge(merged_df, df_sorter, how="outer", left_on=['Source Instance Name','Source Field Name'],
                             right_on=['Input Transformation','Field Name'])
    # print("Merging Aggregator..")
    if len(df_aggregator)!=0:
        merged_df = pd.merge(merged_df, df_aggregator, how="outer", left_on=['Source Instance Name','Source Field Name'],
                             right_on=['Input Transformation','Field Name'])
    # print("Merging Reusability..")
    if len(df_reusability)!=0:
        merged_df = pd.merge(merged_df, df_reusability, how="outer", left_on=['Source Instance Name'],
                             right_on=['Input Transformation'])

    # print("Merging Union..")
    if len(df_union)!=0:
        merged_df = pd.merge(merged_df, df_union, how="outer", left_on=['Source Instance Type','Source Instance Name','Source Field Name'],
                             right_on=['TRANSFORMATION_TYPE','Instance Name','COLUMN NAME'])

    merged_df.to_csv('base_df.csv',index=False)
    if 'Database Name' not in merged_df:
        merged_df['Database Name'] = ""
    if 'Is_SortKey?' not in merged_df:
        merged_df['Is_SortKey?'] = ""
    if 'Sort Order' not in merged_df:
        merged_df['Sort Order'] = ""
    if 'Filter Condition' not in merged_df:
        merged_df['Filter Condition'] = ""
    if 'Lookup sql override' not in merged_df:
        merged_df['Lookup sql override'] = ""
    if 'Pre SQL'not in merged_df:
        merged_df['Pre SQL'] = ""
    if 'Post SQL'not in merged_df:
        merged_df['Post SQL'] = ""
    if 'Expression' not in merged_df:
        merged_df['Expression'] = ""
    if 'Aggregator Port Type'not in merged_df:
        merged_df['Aggregator Port Type'] = ""
    if 'Aggregator Type' not in merged_df:
        merged_df['Aggregator Type'] = ""
    if 'Resusable' not in merged_df:
        merged_df['Resusable'] = ""
    if 'Transformation type' not in merged_df:
        merged_df['Transformation type'] = ""
    if 'GROUP' not in merged_df:
        merged_df['GROUP'] = ""
    if 'EXPRESSION' not in merged_df:
        merged_df['EXPRESSION'] = ""
    if 'TRANSFORMATION_TYPE' not in merged_df:
        merged_df['TRANSFORMATION_TYPE'] = ""
    if 'GROUP NAME' not in merged_df:
        merged_df['GROUP NAME'] = ""
    if 'GROUP DESCRIPTION' not in merged_df:
        merged_df['GROUP DESCRIPTION'] = ""
    if 'Port Type_x' not in merged_df:
        merged_df['Port Type_x']=""
    final_merged_df=merged_df[['File Index','Target Index','Key Index','Source Instance Type','Source Instance Name','Database Name','Source Field Name','Target Instance Type','Target Instance Name','Target Field Name','Port Type_x','Expression','Source Override SQL','Pre SQL','Post SQL','Join Condition','Join Type','Lookup Join Condition','Lookup sql override','Filter Condition','Is_SortKey?','Sort Order','Aggregator Type','Aggregator Port Type','Aggregator Expression','Resusable','Transformation type', 'GROUP','ROUTER EXPRESSION','GROUP NAME','GROUP DESCRIPTION']].copy()
    final_merged_df=final_merged_df.drop_duplicates()
    final_merged_df=final_merged_df.sort_values(by=['Target Index','Key Index'])
    final_merged_df=final_merged_df[np.isfinite(final_merged_df['Target Index'])]
    final_merged_df.to_csv('updated_base_df.csv',index=False)
    # print(merged_df)
    final_dataframe = pd.concat([final_dataframe, final_merged_df])



# print(final_dataframe)

final_dataframe.replace(['Custom Transformation'], ['Union Transformation'])
final_dataframe['Source Instance Type'] = final_dataframe['Source Instance Type'].str.replace("Custom Transformation","Union Transformation")
final_dataframe['Target Instance Type'] = final_dataframe['Target Instance Type'].str.replace("Custom Transformation","Union Transformation")
final_dataframe.to_csv("Final_DataFrame.csv")

# print("XML Parse Activity Complete")
# print("Activity End Time: "+str(datetime.datetime.now())+"\n")

#Generate the Main ouput file
# df=pd.DataFrame(columns = ['Mapping Index','Target Index','Mapping Name','Source Instance Type','Source Instance', 'Source Location','Source Field','Target Instance Type','Target Instance', 'Target Field','Port Type','Expression','Source Override SQL','Pre Post SQL','Lookup Join Condition','Joiner Extract','Filter Expression','Re-usable Tranformation','Is Sort Key?','Sort Order','Resusable','Transformation type', 'GROUP','EXPRESSION','TRANSFORMATION TEMPLATE','GROUP NAME','GROUP DESCRIPTION'],data=final_dataframe_list)
# df.to_csv("Output_Dataframe.csv",index=False)

#Generate Log File
activity_end_time = str(datetime.datetime.now())
log_dataframe_list.append([activity_start_time,activity_end_time,mapping_name+".xml",str(len(target_wise_linked_dict.keys())),"Pass",""])
log_df=pd.DataFrame(columns=['Activity Start Time','Activity End Time','Mapping Name','Targets Parsed','Status','Comments'],data=log_dataframe_list)
log_df.to_csv("Log.csv")

#Generate the Mapping Output File
# df_subset= df[['Mapping Name','Target Index','Source Instance Type', 'Source Instance', 'Target Instance Type','Target Instance']].copy()
# df_source=final_dataframe[['Mapping Name','Target Index','Source Instance Type', 'Source Instance']].copy()
# df_source=df_source[(final_dataframe['Source Instance Type'] == 'Source Definition')]
# df_target=final_dataframe[['Mapping Name','Target Index','Target Instance Type', 'Target Instance']].copy()
# df_target=df_target[(final_dataframe['Target Instance Type'] == 'Target Definition')]
# mapping_df=pd.merge(df_source, df_target, on=['Mapping Name','Target Index'],how='right')
# mapping_df=mapping_df[['Mapping Name','Source Instance Type', 'Source Instance','Target Instance Type', 'Target Instance']].copy()
# mapping_df=mapping_df.drop_duplicates()
# mapping_df.to_csv("SRC_TGT_MAP.csv",index=False)

# df_source.to_csv("SRC_LIST.csv",index=False)
#print(df_source)
#print(df_target)
    # #print(target_field_instance_list)
    #print (target_to_source_linked_dict)